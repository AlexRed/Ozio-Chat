defined('JPATH_PLATFORM') or die("Restricted access");

	/*
	This file is part of "Ozio Chat Joomla Extension".
	Author: Open Source solutions http://www.opensourcesolutions.es

	You can redistribute and/or modify it under the terms of the GNU
	General Public License as published by the Free Software Foundation,
	either version 2 of the License, or (at your option) any later version.

	GNU/GPL license gives you the freedom:
	* to use this software for both commercial and non-commercial purposes
	* to share, copy, distribute and install this software and charge for it if you wish.

	Under the following conditions:
	* You must attribute the work to the original author

	This software is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this software.  If not, see http://www.gnu.org/licenses/gpl-2.0.html.

	@copyright Copyright (C) 2015 Open Source Solutions S.L.U. All rights reserved.
	*/

JFactory::getLanguage()->load("oziochat", JPATH_ROOT . "/libraries/oziochat");

$version = new JVersion();
switch ($version->RELEASE)
{
	case "1.6":
		$GLOBALS["toSql"] = "toMySQL";
		$GLOBALS["quoteName"] = "nameQuote";
		break;

	case "1.7":
		$GLOBALS["toSql"] = "toMySQL";
		$GLOBALS["quoteName"] = "quoteName";
		break;

	default:
		$GLOBALS["toSql"] = "toSql";
		$GLOBALS["quoteName"] = "quoteName";
}

$xml = JFactory::getXML(JPATH_ADMINISTRATOR . "/components/com_oziochat/oziochat.xml");
$db = JFactory::getDBO();
$query = $db->getQuery(true);
$query = "SELECT `location` FROM `#__update_sites` WHERE `name` = 'OzioChat update site';";
$db->setQuery($query);
$GLOBALS["oziochat"]["version"] = (string)$xml->version . " " . (md5($db->loadResult()) == "ee67ec9d8d502927afaf79aa227c8d61");

if (!function_exists("oc_icons_path"))
{
	function oc_icons_path($dummy)
	{
		echo oc_copyrightchat("OzioChat");
		return "";
	}
}


if (!function_exists("oc_template"))
{
	function oc_template($id, $noscript, $streetview)
	{
		$html = "<div id=\"oziochat_wrapper_plugin_$id\">
					<div id=\"oziochat_container_plugin_$id\">
						<div id=\"oziochat_plugin_$id\">
							<noscript>$noscript</noscript>
						</div>
					</div>";
		$html.=oc_copyrightchat("OzioChat");
		$html .= "</div>";
		
		return $html;
	}
}


if (!function_exists("oc_copyrightchat"))
{
	function oc_copyrightchat($titolomap)
	{
		$astilemap = array();
		$astilemap[] = "text-decoration:none !important";
		$sstile_amap = implode(";", $astilemap);

		$astilemap = array();
		$astilemap[] = "clear:both !important";
		$astilemap[] = "padding:10px 0 !important";

		$astilemap[] = "font-family:arial,verdana,sans-serif !important";
		$astilemap[] = "font-size:10px !important";
		$astilemap[] = "font-variant:small-caps !important";

		$sstile_divmap = implode(";", $astilemap);

		$urlmap = "http://www.joomla.it";
		$testomap = "Joomla.it";

		$document = JFactory::getDocument();

		$head = "
		</script>
		<script type='text/javascript'>
		";
		
		//$document->addScriptDeclaration($head);
		
		$body = array(
			'<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>',
			'<!-- Estensioni OSS  320x50 -->',
			'<ins class="adsbygoogle"',
			'	 style="display:inline-block;width:320px;height:50px"',
			'	 data-ad-client="ca-pub-5993962446883481"',
			'	 data-ad-slot="3616966072"></ins>',
			'<script>',
			'(adsbygoogle = window.adsbygoogle || []).push({});',
			'</script>',
		);
		return implode("\n",$body);
		
		
	}
}
