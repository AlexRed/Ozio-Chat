defined('JPATH_PLATFORM') or die("Restricted access");
JFactory::getLanguage()->load("oziochat", JPATH_ROOT . "/libraries/oziochat");

$version = new JVersion();
switch ($version->RELEASE)
{
	case "1.6":
		$GLOBALS["toSql"] = "toMySQL";
		$GLOBALS["quoteName"] = "nameQuote";
		break;

	case "1.7":
		$GLOBALS["toSql"] = "toMySQL";
		$GLOBALS["quoteName"] = "quoteName";
		break;

	default:
		$GLOBALS["toSql"] = "toSql";
		$GLOBALS["quoteName"] = "quoteName";
}

$xml = JFactory::getXML(JPATH_ADMINISTRATOR . "/components/com_oziochat/oziochat.xml");
$db = JFactory::getDBO();
$query = $db->getQuery(true);
$query = "SELECT `location` FROM `#__update_sites` WHERE `name` = 'OzioChat update site';";
$db->setQuery($query);
$GLOBALS["oziochat"]["version"] = (string)$xml->version . " " . (md5($db->loadResult()) == "ee67ec9d8d502927afaf79aa227c8d61");

if (!function_exists("oc_icons_path"))
{
	function oc_icons_path($dummy)
	{
		echo oc_copyrightchat("OzioChat");
		return "";
	}
}


if (!function_exists("oc_template"))
{
	function oc_template($id, $noscript, $streetview)
	{
		$html = "<div id=\"oziochat_wrapper_plugin_$id\">
					<div id=\"oziochat_container_plugin_$id\">
						<div id=\"oziochat_plugin_$id\">
							<noscript>$noscript</noscript>
						</div>
					</div>";
		$html.=oc_copyrightchat("OzioChat");
		$html .= "</div>";
		
		return $html;
	}
}


if (!function_exists("oc_copyrightchat"))
{
	function oc_copyrightchat($titolomap)
	{
		$astilemap = array();
		$astilemap[] = "text-decoration:none !important";
		$sstile_amap = implode(";", $astilemap);

		$astilemap = array();
		$astilemap[] = "clear:both !important";
		$astilemap[] = "padding:10px 0 !important";

		$astilemap[] = "font-family:arial,verdana,sans-serif !important";
		$astilemap[] = "font-size:10px !important";
		$astilemap[] = "font-variant:small-caps !important";

		$sstile_divmap = implode(";", $astilemap);

		$urlmap = "http://www.joomla.it";
		$testomap = "Joomla.it";

		$document = JFactory::getDocument();

		$head = "
		</script>
		<script type='text/javascript'>
		  (function() {
			var useSSL = 'https:' == document.location.protocol;
			var src = (useSSL ? 'https:' : 'http:') +
				'//www.googletagservices.com/tag/js/gpt.js';
			document.write('<scr' + 'ipt src=\"' + src + '\"></scr' + 'ipt>');
		  })();
		 </script>
		<script type='text/javascript'>
		  googletag.cmd.push(function() {
			googletag.defineSlot('/4340278/oss', [320, 50], 'div-gpt-ad-1435346115575-0').addService(googletag.pubads());
			googletag.pubads().enableSingleRequest();
			googletag.pubads().enableSyncRendering();
			googletag.enableServices();
		  });
		 </script>
		<script type='text/javascript'>
		";
		
		$document->addScriptDeclaration($head);
		
		$body = array(
			"<!-- /4340278/oss -->",
			"<div id='div-gpt-ad-1435346115575-0' style='height:50px; width:320px;'>",
			"<script type='text/javascript'>",
			"googletag.cmd.push(function() { googletag.display('div-gpt-ad-1435346115575-0'); });",
			"</script>",
			"</div>"
		);
		return implode("\n",$body);
		
		
	}
}
